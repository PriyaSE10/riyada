const flipBook = (elBook) => {
  if (!elBook || !elBook.querySelector(".page")) {
    return; // Exit if the elBook or .page element is not found
  }
  function sendMail() {
    Email.send({
      Host: "smtp.gmail.com",
      Username: "username",
      Password: "password",
      To: "<EMAIL>",
      From: "<EMAIL>",
      Subject: "Subject",
      Body: "Body",
    }).then((message) => alert(message));
  }

  elBook.style.setProperty("--c", 0); // Set current page
  elBook.querySelectorAll(".page").forEach((page, idx) => {
    page.style.setProperty("--i", idx);
    page.addEventListener("click", (evt) => {
      if (evt.target.closest("a")) return;
      const curr = evt.target.closest(".back") ? idx : idx + 1;
      elBook.style.setProperty("--c", curr);
    });
  });
};
var pageLink = window.location.href.split('/').slice(-1);
console.log(pageLink[0]);


function muteYouTubeVideo() {
  var iframe = document.getElementById("youtubeVideo");
  var player = new URLSearchParams(new URL(iframe.src).search).get("autoplay");
  if (player === "1") {
    var message = {
      event: "command",
      func: "mute",
      args: [],
    };
    iframe.contentWindow.postMessage(JSON.stringify(message), "*");
  }
}

window.addEventListener("message", function (e) {
  if (e.data === "closeVideo") {
    muteYouTubeVideo(); // Mute the audio when the iframe is closed
  }
});

// document.addEventListener("DOMContentLoaded", function () {
//   const readMoreBtn = document.getElementById("read-more-btn");
//   const content = document.querySelector(".content");

//   readMoreBtn.addEventListener("click", function () {
//     content.classList.toggle("show-content");
//     readMoreBtn.textContent = content.classList.contains("show-content")
//       ? "Read less"
//       : "Read more";
//   });
// });

document.querySelectorAll(".book").forEach(flipBook);
$(document).ready(function () {
  // Owl Carousel
  var owl = $("#home-owl-carousel");
  owl.owlCarousel({
    loop: true,
    center: true,
    margin: 30,
    animateOut: "fadeOut",
    stagePadding: 250,
    nav: true,
    dots: false,
    items: 1,
    autoplay: true,
    delay: 3000,
  });
});

// document.addEventListener("DOMContentLoaded", function () {
//   const toggleButton = document.getElementById("toggle-audio");
//   const audio = document.getElementById("background-audio");
//   audio.play();

//   toggleButton.addEventListener("click", function () {
//     if (audio.paused) {
//       audio.play();
//       toggleButton.textContent = "Pause Audio";
//     } else {
//       audio.pause();
//       toggleButton.textContent = "Play Audio";
//     }
//   });
// });
$(document).ready(function () {
  // Owl Carousel
  var owl = $("#carousel");
  owl.owlCarousel({
    loop: true,

    nav: false,
    dots: true,
    items: 1,
    autoplay: false,
    delay: 3000,
  });
});
$(document).ready(function () {
  // Owl Carousel
  var owl = $("#carousel-mobile");
  owl.owlCarousel({
    loop: true,

    nav: false,
    dots: true,
    items: 1,
    autoplay: false,
    delay: 3000,
  });
});
$(document).ready(function () {
  // Owl Carousel
  var owl = $("#testimonials-owl-carousel");
  owl.owlCarousel({
    loop: true,
    margin: 30,
    nav: true,
    dots: true,
    items: 1,
    autoplay: true,
    delay: 3000,
  });
});

document.addEventListener("DOMContentLoaded", function () {
  // Function to handle video popup functionality
  function handleVideoPopup() {
    const playButtons = document.querySelectorAll(".play-button");
    const popupContainers = document.querySelectorAll(".popup-video-container");
    const playPauseButtons = document.querySelectorAll(".play-pause-button");
    const closePopups = document.querySelectorAll(".close-popup");
    const videos = document.querySelectorAll(".popup-video video");

    // Mute all videos initially
    videos.forEach(function (video) {
      video.muted = true;
    });

    playButtons.forEach(function (img, index) {
      img.addEventListener("click", function () {
        popupContainers.forEach(function (container) {
          container.style.display = "none";
        });
        popupContainers[index].style.display = "block";
      });
    });

    playPauseButtons.forEach(function (playPauseButton, index) {
      playPauseButton.addEventListener("click", function () {
        const video = playPauseButton
          .closest(".popup-video-container")
          .querySelector("video");
        if (video.paused) {
          video.play();
          video.muted = false; // Unmute the clicked video
        } else {
          video.pause();
        }
      });
    });

    closePopups.forEach(function (closeButton) {
      closeButton.addEventListener("click", function () {
        closeButton.parentNode.parentNode.style.display = "none";
        const video = closeButton.parentNode.querySelector("video");
        video.pause();
        video.muted = true; // Mute the video when closing the popup
        video.src = ""; // Reset the video source
      });
    });
  }

  function handleAudioToggle() {
    const toggleButton = document.getElementById("toggle-audio");
    const audio = document.getElementById("background-audio");
    const playImg = "./assets/img/play-button.png";
    const pauseImg = "./assets/img/pause-button.png";
    audio.play();
    function updateImage() {
      if (audio.paused) {
        toggleButton.src = pauseImg; // Change image to play button
      } else {
        toggleButton.src = playImg; // Change image to pause button
      }
    }
    updateImage();

    toggleButton.addEventListener("click", function () {
      if (audio.paused) {
        audio.play();
      } else {
        audio.pause();
      }
      updateImage();
    });
  }

  // Call the functions to initialize their respective event listeners
  handleVideoPopup();
  handleAudioToggle();
});
// document.addEventListener("DOMContentLoaded", function () {
//   const playButtons = document.querySelectorAll(".play-button");
//   const popupContainers = document.querySelectorAll(".popup-video-container");
//   const playPauseButtons = document.querySelectorAll(".play-pause-button");
//   const closePopups = document.querySelectorAll(".close-popup");
//   const videos = document.querySelectorAll(".popup-video video");

//   playButtons.forEach(function (img, index) {
//     img.addEventListener("click", function () {

//       popupContainers.forEach(function (container) {
//         container.style.display = "none";
//       });
//       popupContainers[index].style.display = "block";
//     });
//   });

//   playPauseButtons.forEach(function (playPauseButton, index) {
//     playPauseButton.addEventListener("click", function () {

//       const video = playPauseButton
//         .closest(".popup-video-container")
//         .querySelector("video");
//       if (video.paused) {
//         video.play();
//       } else {
//         video.pause();
//         video.muted = true;
//       }
//     });
//   });

//   closePopups.forEach(function (closeButton) {
//     closeButton.addEventListener("click", function () {
//       // Hide the popup container when close button is clicked
//       closeButton.parentNode.parentNode.style.display = "none";
//       // Pause the video inside the closed popup container
//       const video = closeButton.parentNode.querySelector("video");
//       video.pause();
//       video.muted = true; // Mute the audio when closing the popup
//       // Stop both the video and its audio by resetting the video's src attribute
//       video.src = "";
//     });
//   });
// });

$(document).ready(function () {
  // Owl Carousel
  var owl = $("#home-owl-mobile-view");
  owl.owlCarousel({
    loop: true,
    // center: true,
    // margin: 30,
    // stagePadding: 250,
    // nav: true,
    dots: true,
    items: 1,
    autoplay: true,
    delay: 3000,
  });
});
if(pageLink[0] !== "index.html"){

  document.addEventListener("DOMContentLoaded", function () {
    
    var readMoreButton = document.getElementById("readMore");
    var extraContent = document.querySelector(".extra-content");
  
    readMoreButton.addEventListener("click", function () {
      if (
        extraContent.style.display === "none" ||
        extraContent.style.opacity === "0"
      ) {
        extraContent.style.display = "flex";
        setTimeout(function () {
          extraContent.style.opacity = "1";
        }, 10); // Added a small delay for smoother transition
        readMoreButton.textContent = "Read less";
      } else {
        extraContent.style.opacity = "0";
        setTimeout(function () {
          extraContent.style.display = "none";
        }, 300); // Delay matches the duration of the transition (0.3s)
        readMoreButton.textContent = "Read more";
      }
    });
  });
}
$(document).ready(function () {
  $(".has-animation").each(function (index) {
    $(this)
      .delay($(this).data("delay"))
      .queue(function () {
        $(this).addClass("animate-in");
      });
  });
});

$(document).ready(function () {
  // Owl Carousel
  var owl = $("#features-owl-carousel");
  owl.owlCarousel({
    loop: true,
    margin: 30,
    nav: true,
    dots: false,
    items: 4,
    animateOut: "slideOutDown",
    animateIn: "flipInX",
    autoplay: true,
    delay: 3000,
    responsiveClass: true,
    responsive: {
      0: {
        items: 2,
      },
      600: {
        items: 3,
      },
      1000: {
        items: 4,
      },
    },
  });
});

const menuToggle = document.querySelector(".menu-toggle");
const sidebar = document.querySelector(".sidebar");
const hamburgerLines = document.querySelectorAll(".hamline");
const closeBtn = document.querySelector(".close-btn");

menuToggle.addEventListener("click", () => {
  sidebar.classList.toggle("show");
  hamburgerLines.forEach((line) => {
    line.classList.toggle("open");
  });
});
closeBtn.addEventListener("click", () => {
  sidebar.classList.remove("show");
  hamburgerLines.forEach((line) => {
    line.classList.remove("open");
  });
  closeBtn.classList.toggle("open");
});

// Remove 'open' class from close button when sidebar is closed
sidebar.addEventListener("transitionend", () => {
  if (!sidebar.classList.contains("show")) {
    closeBtn.classList.remove("open");
  }
});

document.addEventListener("DOMContentLoaded", function () {
  const cards = document.querySelectorAll(
    ".feature-section-card p:first-child"
  );
  let hasStarted = false; // To prevent the animation from restarting

  function animateNumber(card, endValue, duration, hasPlus) {
    let startValue = 0;
    let startTime = null;

    function animation(currentTime) {
      if (startTime === null) startTime = currentTime;
      const timeElapsed = currentTime - startTime;
      const progress = Math.min(timeElapsed / duration, 1);

      const currentValue = Math.floor(
        progress * (endValue - startValue) + startValue
      );
      card.textContent = currentValue.toString() + (hasPlus ? "+" : "");

      if (timeElapsed < duration) {
        requestAnimationFrame(animation);
      } else {
        // Ensure it ends on the exact value, appending '+' if necessary
        card.textContent = endValue.toString() + (hasPlus ? "+" : "");
      }
    }

    requestAnimationFrame(animation);
  }

  const observer = new IntersectionObserver(
    function (entries) {
      entries.forEach((entry) => {
        if (entry.isIntersecting && !hasStarted) {
          hasStarted = true; // Ensures we only animate once
          cards.forEach((card) => {
            const textContent = card.textContent;
            const hasPlus = textContent.includes("+");
            const endValue = parseInt(textContent, 10); // Parses the numeric part
            animateNumber(card, endValue, 2000, hasPlus); // Pass the hasPlus flag
          });
        }
      });
    },
    {
      threshold: 0.5, // This means the animation starts when half of the section is visible
    }
  );

  observer.observe(document.querySelector(".feature-section"));
});

function launchParticlesJS(a, e) {
  var i = document.querySelector("#" + a + " > canvas");
  pJS = {
    canvas: {
      el: i,
      w: i.offsetWidth,
      h: i.offsetHeight,
    },
    particles: {
      color: "#fff",
      shape: "circle",
      opacity: 1,
      size: 2.5,
      size_random: true,
      nb: 200,
      line_linked: {
        enable_auto: true,
        distance: 100,
        color: "#fff",
        opacity: 1,
        width: 1,
        condensed_mode: {
          enable: true,
          rotateX: 65000,
          rotateY: 65000,
        },
      },
      anim: {
        enable: true,
        speed: 1,
      },
      array: [],
    },
    interactivity: {
      enable: true,
      mouse: {
        distance: 100,
      },
      detect_on: "canvas",
      mode: "grab",
      line_linked: {
        opacity: 1,
      },
      events: {
        onclick: {
          enable: true,
          mode: "push",
          nb: 4,
        },
      },
    },
    retina_detect: false,
    fn: {
      vendors: {
        interactivity: {},
      },
    },
  };
  if (e) {
    if (e.particles) {
      var b = e.particles;
      if (b.color) {
        pJS.particles.color = b.color;
      }
      if (b.shape) {
        pJS.particles.shape = b.shape;
      }
      if (b.opacity) {
        pJS.particles.opacity = b.opacity;
      }
      if (b.size) {
        pJS.particles.size = b.size;
      }
      if (b.size_random == false) {
        pJS.particles.size_random = b.size_random;
      }
      if (b.nb) {
        pJS.particles.nb = b.nb;
      }
      if (b.line_linked) {
        var j = b.line_linked;
        if (j.enable_auto == false) {
          pJS.particles.line_linked.enable_auto = j.enable_auto;
        }
        if (j.distance) {
          pJS.particles.line_linked.distance = j.distance;
        }
        if (j.color) {
          pJS.particles.line_linked.color = j.color;
        }
        if (j.opacity) {
          pJS.particles.line_linked.opacity = j.opacity;
        }
        if (j.width) {
          pJS.particles.line_linked.width = j.width;
        }
        if (j.condensed_mode) {
          var g = j.condensed_mode;
          if (g.enable == false) {
            pJS.particles.line_linked.condensed_mode.enable = g.enable;
          }
          if (g.rotateX) {
            pJS.particles.line_linked.condensed_mode.rotateX = g.rotateX;
          }
          if (g.rotateY) {
            pJS.particles.line_linked.condensed_mode.rotateY = g.rotateY;
          }
        }
      }
      if (b.anim) {
        var k = b.anim;
        if (k.enable == false) {
          pJS.particles.anim.enable = k.enable;
        }
        if (k.speed) {
          pJS.particles.anim.speed = k.speed;
        }
      }
    }
    if (e.interactivity) {
      var c = e.interactivity;
      if (c.enable == false) {
        pJS.interactivity.enable = c.enable;
      }
      if (c.mouse) {
        if (c.mouse.distance) {
          pJS.interactivity.mouse.distance = c.mouse.distance;
        }
      }
      if (c.detect_on) {
        pJS.interactivity.detect_on = c.detect_on;
      }
      if (c.mode) {
        pJS.interactivity.mode = c.mode;
      }
      if (c.line_linked) {
        if (c.line_linked.opacity) {
          pJS.interactivity.line_linked.opacity = c.line_linked.opacity;
        }
      }
      if (c.events) {
        var d = c.events;
        if (d.onclick) {
          var h = d.onclick;
          if (h.enable == false) {
            pJS.interactivity.events.onclick.enable = false;
          }
          if (h.mode != "push") {
            pJS.interactivity.events.onclick.mode = h.mode;
          }
          if (h.nb) {
            pJS.interactivity.events.onclick.nb = h.nb;
          }
        }
      }
    }
    pJS.retina_detect = e.retina_detect;
  }
  pJS.particles.color_rgb = hexToRgb(pJS.particles.color);
  pJS.particles.line_linked.color_rgb_line = hexToRgb(
    pJS.particles.line_linked.color
  );
  if (pJS.retina_detect && window.devicePixelRatio > 1) {
    pJS.retina = true;
    pJS.canvas.pxratio = window.devicePixelRatio;
    pJS.canvas.w = pJS.canvas.el.offsetWidth * pJS.canvas.pxratio;
    pJS.canvas.h = pJS.canvas.el.offsetHeight * pJS.canvas.pxratio;
    pJS.particles.anim.speed = pJS.particles.anim.speed * pJS.canvas.pxratio;
    pJS.particles.line_linked.distance =
      pJS.particles.line_linked.distance * pJS.canvas.pxratio;
    pJS.particles.line_linked.width =
      pJS.particles.line_linked.width * pJS.canvas.pxratio;
    pJS.interactivity.mouse.distance =
      pJS.interactivity.mouse.distance * pJS.canvas.pxratio;
  }
  pJS.fn.canvasInit = function () {
    pJS.canvas.ctx = pJS.canvas.el.getContext("2d");
  };
  pJS.fn.canvasSize = function () {
    pJS.canvas.el.width = pJS.canvas.w;
    pJS.canvas.el.height = pJS.canvas.h;
    window.onresize = function () {
      if (pJS) {
        pJS.canvas.w = pJS.canvas.el.offsetWidth;
        pJS.canvas.h = pJS.canvas.el.offsetHeight;
        if (pJS.retina) {
          pJS.canvas.w *= pJS.canvas.pxratio;
          pJS.canvas.h *= pJS.canvas.pxratio;
        }
        pJS.canvas.el.width = pJS.canvas.w;
        pJS.canvas.el.height = pJS.canvas.h;
        pJS.fn.canvasPaint();
        if (!pJS.particles.anim.enable) {
          pJS.fn.particlesRemove();
          pJS.fn.canvasRemove();
          f();
        }
      }
    };
  };
  pJS.fn.canvasPaint = function () {
    pJS.canvas.ctx.fillRect(0, 0, pJS.canvas.w, pJS.canvas.h);
  };
  pJS.fn.canvasRemove = function () {
    pJS.canvas.ctx.clearRect(0, 0, pJS.canvas.w, pJS.canvas.h);
  };
  pJS.fn.particle = function (n, o, m) {
    this.x = m ? m.x : Math.random() * pJS.canvas.w;
    this.y = m ? m.y : Math.random() * pJS.canvas.h;
    this.radius =
      (pJS.particles.size_random ? Math.random() : 1) * pJS.particles.size;
    if (pJS.retina) {
      this.radius *= pJS.canvas.pxratio;
    }
    this.color = n;
    this.opacity = o;
    this.vx = -0.5 + Math.random();
    this.vy = -0.5 + Math.random();
    this.draw = function () {
      pJS.canvas.ctx.fillStyle =
        "rgba(" +
        this.color.r +
        "," +
        this.color.g +
        "," +
        this.color.b +
        "," +
        this.opacity +
        ")";
      pJS.canvas.ctx.beginPath();
      switch (pJS.particles.shape) {
        case "circle":
          pJS.canvas.ctx.arc(
            this.x,
            this.y,
            this.radius,
            0,
            Math.PI * 2,
            false
          );
          break;
        case "edge":
          pJS.canvas.ctx.rect(this.x, this.y, this.radius * 2, this.radius * 2);
          break;
        case "triangle":
          pJS.canvas.ctx.moveTo(this.x, this.y - this.radius);
          pJS.canvas.ctx.lineTo(this.x + this.radius, this.y + this.radius);
          pJS.canvas.ctx.lineTo(this.x - this.radius, this.y + this.radius);
          pJS.canvas.ctx.closePath();
          break;
      }
      pJS.canvas.ctx.fill();
    };
  };
  pJS.fn.particlesCreate = function () {
    for (var m = 0; m < pJS.particles.nb; m++) {
      pJS.particles.array.push(
        new pJS.fn.particle(pJS.particles.color_rgb, pJS.particles.opacity)
      );
    }
  };
  pJS.fn.particlesAnimate = function () {
    for (var n = 0; n < pJS.particles.array.length; n++) {
      var q = pJS.particles.array[n];
      q.x += q.vx * (pJS.particles.anim.speed / 2);
      q.y += q.vy * (pJS.particles.anim.speed / 2);
      if (q.x - q.radius > pJS.canvas.w) {
        q.x = q.radius;
      } else {
        if (q.x + q.radius < 0) {
          q.x = pJS.canvas.w + q.radius;
        }
      }
      if (q.y - q.radius > pJS.canvas.h) {
        q.y = q.radius;
      } else {
        if (q.y + q.radius < 0) {
          q.y = pJS.canvas.h + q.radius;
        }
      }
      for (var m = n + 1; m < pJS.particles.array.length; m++) {
        var o = pJS.particles.array[m];
        if (pJS.particles.line_linked.enable_auto) {
          pJS.fn.vendors.distanceParticles(q, o);
        }
        if (pJS.interactivity.enable) {
          switch (pJS.interactivity.mode) {
            case "grab":
              pJS.fn.vendors.interactivity.grabParticles(q, o);
              break;
          }
        }
      }
    }
  };
  pJS.fn.particlesDraw = function () {
    pJS.canvas.ctx.clearRect(0, 0, pJS.canvas.w, pJS.canvas.h);
    pJS.fn.particlesAnimate();
    for (var m = 0; m < pJS.particles.array.length; m++) {
      var n = pJS.particles.array[m];
      n.draw(
        "rgba(" +
          n.color.r +
          "," +
          n.color.g +
          "," +
          n.color.b +
          "," +
          n.opacity +
          ")"
      );
    }
  };
  pJS.fn.particlesRemove = function () {
    pJS.particles.array = [];
  };
  pJS.fn.vendors.distanceParticles = function (t, r) {
    var o = t.x - r.x,
      n = t.y - r.y,
      s = Math.sqrt(o * o + n * n);
    if (s <= pJS.particles.line_linked.distance) {
      var m = pJS.particles.line_linked.color_rgb_line;
      pJS.canvas.ctx.beginPath();
      pJS.canvas.ctx.strokeStyle =
        "rgba(" +
        m.r +
        "," +
        m.g +
        "," +
        m.b +
        "," +
        (pJS.particles.line_linked.opacity -
          s / pJS.particles.line_linked.distance) +
        ")";
      pJS.canvas.ctx.moveTo(t.x, t.y);
      pJS.canvas.ctx.lineTo(r.x, r.y);
      pJS.canvas.ctx.lineWidth = pJS.particles.line_linked.width;
      pJS.canvas.ctx.stroke();
      pJS.canvas.ctx.closePath();
      if (pJS.particles.line_linked.condensed_mode.enable) {
        var o = t.x - r.x,
          n = t.y - r.y,
          q = o / (pJS.particles.line_linked.condensed_mode.rotateX * 1000),
          p = n / (pJS.particles.line_linked.condensed_mode.rotateY * 1000);
        r.vx += q;
        r.vy += p;
      }
    }
  };
  pJS.fn.vendors.interactivity.listeners = function () {
    if (pJS.interactivity.detect_on == "window") {
      var m = window;
    } else {
      var m = pJS.canvas.el;
    }
    m.onmousemove = function (p) {
      if (m == window) {
        var o = p.clientX,
          n = p.clientY;
      } else {
        var o = p.offsetX || p.clientX,
          n = p.offsetY || p.clientY;
      }
      if (pJS) {
        pJS.interactivity.mouse.pos_x = o;
        pJS.interactivity.mouse.pos_y = n;
        if (pJS.retina) {
          pJS.interactivity.mouse.pos_x *= pJS.canvas.pxratio;
          pJS.interactivity.mouse.pos_y *= pJS.canvas.pxratio;
        }
        pJS.interactivity.status = "mousemove";
      }
    };
    m.onmouseleave = function (n) {
      if (pJS) {
        pJS.interactivity.mouse.pos_x = 0;
        pJS.interactivity.mouse.pos_y = 0;
        pJS.interactivity.status = "mouseleave";
      }
    };
    if (pJS.interactivity.events.onclick.enable) {
      switch (pJS.interactivity.events.onclick.mode) {
        case "push":
          m.onclick = function (o) {
            if (pJS) {
              for (var n = 0; n < pJS.interactivity.events.onclick.nb; n++) {
                pJS.particles.array.push(
                  new pJS.fn.particle(
                    pJS.particles.color_rgb,
                    pJS.particles.opacity,
                    {
                      x: pJS.interactivity.mouse.pos_x,
                      y: pJS.interactivity.mouse.pos_y,
                    }
                  )
                );
              }
            }
          };
          break;
        case "remove":
          m.onclick = function (n) {
            pJS.particles.array.splice(0, pJS.interactivity.events.onclick.nb);
          };
          break;
      }
    }
  };
  pJS.fn.vendors.interactivity.grabParticles = function (r, q) {
    var u = r.x - q.x,
      s = r.y - q.y,
      p = Math.sqrt(u * u + s * s);
    var t = r.x - pJS.interactivity.mouse.pos_x,
      n = r.y - pJS.interactivity.mouse.pos_y,
      o = Math.sqrt(t * t + n * n);
    if (
      p <= pJS.particles.line_linked.distance &&
      o <= pJS.interactivity.mouse.distance &&
      pJS.interactivity.status == "mousemove"
    ) {
      var m = pJS.particles.line_linked.color_rgb_line;
      pJS.canvas.ctx.beginPath();
      pJS.canvas.ctx.strokeStyle =
        "rgba(" +
        m.r +
        "," +
        m.g +
        "," +
        m.b +
        "," +
        (pJS.interactivity.line_linked.opacity -
          o / pJS.interactivity.mouse.distance) +
        ")";
      pJS.canvas.ctx.moveTo(r.x, r.y);
      pJS.canvas.ctx.lineTo(
        pJS.interactivity.mouse.pos_x,
        pJS.interactivity.mouse.pos_y
      );
      pJS.canvas.ctx.lineWidth = pJS.particles.line_linked.width;
      pJS.canvas.ctx.stroke();
      pJS.canvas.ctx.closePath();
    }
  };
  pJS.fn.vendors.destroy = function () {
    cancelAnimationFrame(pJS.fn.requestAnimFrame);
    i.remove();
    delete pJS;
  };

  function f() {
    pJS.fn.canvasInit();
    pJS.fn.canvasSize();
    pJS.fn.canvasPaint();
    pJS.fn.particlesCreate();
    pJS.fn.particlesDraw();
  }

  function l() {
    pJS.fn.particlesDraw();
    pJS.fn.requestAnimFrame = requestAnimFrame(l);
  }
  f();
  if (pJS.particles.anim.enable) {
    l();
  }
  if (pJS.interactivity.enable) {
    pJS.fn.vendors.interactivity.listeners();
  }
}
window.requestAnimFrame = (function () {
  return (
    window.requestAnimationFrame ||
    window.webkitRequestAnimationFrame ||
    window.mozRequestAnimationFrame ||
    window.oRequestAnimationFrame ||
    window.msRequestAnimationFrame ||
    function (a) {
      window.setTimeout(a, 1000 / 60);
    }
  );
})();
window.cancelRequestAnimFrame = (function () {
  return (
    window.cancelAnimationFrame ||
    window.webkitCancelRequestAnimationFrame ||
    window.mozCancelRequestAnimationFrame ||
    window.oCancelRequestAnimationFrame ||
    window.msCancelRequestAnimationFrame ||
    clearTimeout
  );
})();

function hexToRgb(c) {
  var b = /^#?([a-f\d])([a-f\d])([a-f\d])$/i;
  c = c.replace(b, function (e, h, f, d) {
    return h + h + f + f + d + d;
  });
  var a = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(c);
  return a
    ? {
        r: parseInt(a[1], 16),
        g: parseInt(a[2], 16),
        b: parseInt(a[3], 16),
      }
    : null;
}
window.particlesJS = function (d, c) {
  if (typeof d != "string") {
    c = d;
    d = "particles-js";
  }
  if (!d) {
    d = "particles-js";
  }
  var b = document.createElement("canvas");
  b.style.width = "100%";
  b.style.height = "100%";
  var a = document.getElementById(d).appendChild(b);
  if (a != null) {
    launchParticlesJS(d, c);
  }
};

/* particlesJS('dom-id', params);
/* @dom-id : set the html tag id [string, optional, default value : particles-js]
/* @params: set the params [object, optional, default values : check particles.js] */

/* config dom id (optional) + config particles params */
particlesJS("particles-js", {
  particles: {
    color: "#fff",
    shape: "circle", // "circle", "edge" or "triangle"
    opacity: 0.5,
    size: 4,
    size_random: true,
    nb: 100, // Increased number of particles
    line_linked: {
      enable_auto: true,
      distance: 100,
      color: "#fff",
      opacity: 1,
      width: 1,
      condensed_mode: {
        enable: false,
        rotateX: 600,
        rotateY: 600,
      },
    },
    anim: {
      enable: true,
      speed: 3,
    },
  },
  interactivity: {
    enable: false,
    mouse: {
      distance: 250,
    },
    detect_on: "canvas", // "canvas" or "window"
    mode: "grab",
    line_linked: {
      opacity: 0.5,
    },
    events: {
      onclick: {
        enable: true,
        mode: "push", // "push" or "remove" (particles)
        nb: 4,
      },
    },
  },
  /* Retina Display Support */
  retina_detect: true,
});

//tabs
$(document).ready(function () {
  $(".tabs > li").click(function () {
    var tab_id = $(this).index() + 1;
    $(".tabs > li").removeClass("current");
    $(".tab-content").removeClass("current");
    $(this).addClass("current");
    $("#tab" + tab_id).addClass("current");
  });
});

// $(document).ready(function () {
//   $(".tabs2 > li").click(function () {
//     var tab_id = $(this).index() + 1;
//     $(".tabs2 > li").removeClass("current");
//     $(".tab-content").removeClass("current");
//     $(this).addClass("current");
//     $("#tab" + tab_id).addClass("current");
//   });
// });


document.addEventListener("DOMContentLoaded", function () {
  setTimeout(function () {
    document.getElementById("backdrop").style.display = "none";
  }, 1500);
});