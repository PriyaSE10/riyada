document.addEventListener('DOMContentLoaded', function () {
  const ham = document.querySelector('.ham');
  const sidebar = document.querySelector('.sidebar');
  const cross = document.querySelector('.sidebar .cross');

  ham.addEventListener('click', function () {
    sidebar.style.right = '0';
  });

  cross.addEventListener('click', function () {
    sidebar.style.right = '-280px';
  });
});

$('.box').on({
  mouseover: function () {
    $(this).find('img:nth-child(1)').stop().animate({ opacity: 0 }, 600);
    $(this).find('img:nth-child(2)').stop().animate({ opacity: 1 }, 600);
  },
  mouseout: function () {
    $(this).find('img:nth-child(1)').stop().animate({ opacity: 1 }, 600);
    $(this).find('img:nth-child(2)').stop().animate({ opacity: 0 }, 600);
  },
});
