function changeLanguage() {
    var selectBox = document.getElementById("language-select");
    var selectedValue = selectBox.value;

    if (selectedValue === "ar") {
        window.location.href = "../rtl/index.php";
    } else {
        window.location.href = "../ltr/index.php";
    }
}




