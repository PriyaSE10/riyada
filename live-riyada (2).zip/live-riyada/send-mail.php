<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
 
require_once "./vendor/autoload.php";

// Check if the form is submitted using POST method
if ($_SERVER["REQUEST_METHOD"] != "POST") {
    // If the form is not submitted properly, redirect to the form page
    header("Location: index.html");
    exit();
}

$firstname = htmlspecialchars($_POST["firstname"]);
$lastname = htmlspecialchars($_POST["lastname"]);
$email = htmlspecialchars($_POST["email"]);
$phone = htmlspecialchars($_POST["tel"]);
$messageContent = htmlspecialchars($_POST["remark"]);
$representing = htmlspecialchars($_POST["representing"]);
$recaptchaResponse = $_POST["g-recaptcha-response"];


// if(empty($firstname) || empty($lastname) || empty($phone) || empty($company) || empty($country) || empty($city) || empty($contactMethod) || empty($messageContent)) {
//    	header("Location: form-wasi.html?error=" . urlencode('Some of the fields are blank. Please check.'));
// 	return;
// }



// Validate that none of the required fields are empty
if (empty($firstname) || empty($lastname) || empty($email) || empty($phone) || empty($messageContent)) {
    // Handle error, perhaps redirect back with an error message
    header("Location: index.html?error=" . urlencode('Some of the required fields are blank. Please check.'));
    return;
}

// Only check if the company field is filled when "Company" is selected in the representing field
if ($representing === 'Company' && empty($company)) {
    // Handle error, redirect back with an error message
    header("Location: index.html?error=" . urlencode('Company name is required when representing a company.'));
    return;
}




// $recaptchaSecret = '6LfgyNMpAAAAAAjbXI6PJ27VXLP0XDHqo0WBbZRv';

// $verifyUrl = 'https://www.google.com/recaptcha/api/siteverify';
// $response = file_get_contents($verifyUrl . '?secret=' . $recaptchaSecret . '&response=' . $recaptchaResponse);
// $responseKeys = json_decode($response, true);

// if (intval($responseKeys["success"]) !== 1) {
// 	$errorMessage = "Oops! It looks like you didn't pass the reCAPTCHA test. Please complete the reCAPTCHA challenge and try again.".$response;
// 	header("Location: form-wasi.html?error=" . urlencode($errorMessage));
// 	exit();
// }
 
$message = '<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>Riyada Training </title>
</head>
<body style="padding:0px; margin:0px;">
    <table cellpadding="0" cellspacing="0" align="center" width="700" class="main-wrap" bgcolor="#F5F5F5" style="font-family: Arial; padding: 22px; margin-top: 50px; border-bottom: 10px solid #ffa500;">
       
        <tr>
            <td style="color: #ffa500; font-size:50px; display: block; padding: 24px 0px; font-weight: 600; text-align: center; padding-bottom: 10px;">
                New Query
            </td>
        </tr>
        <tr>
            <td style="color:#444444; line-height:32px; font-family:arial; font-size:18px; text-align: center;">
                A new customer has reached, contact them shortly
            </td>
        </tr>
        <tr>
            <td>
                <table cellpadding="0" cellspacing="0" style="padding-top: 24px; width: 100%;">
                    <tr>
                        <td style="background: #fff; padding: 10px 14px; width: 24%">First Name</td>
                        <td style="background: #faf9ee; padding: 10px 14px; font-weight: 600;">' . $firstname . '</td>
                    </tr>
                </table>
            </td>
        </tr>
        <tr>
            <td>
                <table cellpadding="0" cellspacing="0" style="padding-top: 14px; width: 100%;">
                    <tr>
                        <td style="background: #fff; padding: 10px 14px; width: 24%">Last Name</td>
                        <td style="background: #faf9ee; padding: 10px 14px; font-weight: 600;">' . $lastname . '</td>
                    </tr>
                </table>
            </td>
        </tr>

         <tr>
            <td>
                <table cellpadding="0" cellspacing="0" style="padding-top: 14px; width: 100%;">
                    <tr>
                        <td style="background: #fff; padding: 10px 14px; width: 24%">Your Email</td>
                        <td style="background: #faf9ee; padding: 10px 14px; font-weight: 600;">' . $email . '</td>
                    </tr>
                </table>
            </td>
        </tr>
       
        <tr>
            <td>
                <table cellpadding="0" cellspacing="0" style="padding-top: 14px; width: 100%;">
                    <tr>
                        <td style="background: #fff; padding: 10px 14px; width: 24%">Mobile Number</td>
                        
                        <td style="background: #faf9ee; padding: 10px 14px; font-weight: 600;"><span>'. $countrycode .'</span><span>'. $phone . '</span></td>
                    </tr>
                </table>
            </td>
        </tr>
       ';




$message .= '<tr>
                <td>
                    <table cellpadding="0" cellspacing="0" style="padding-top: 14px; width: 100%;">
                        <tr>
                            <td style="background: #fff; padding: 10px 14px; width: 24%">Message </td>
                            <td style="background: #faf9ee; padding: 10px 14px; font-weight: 600;">' . $messageContent . '</td>
                        </tr>
                    </table>
                </td>
            </tr>';

$message .= '</table>
</body>
</html>';
 
$mail = new PHPMailer(true);
 
try {
    $mail->SMTPDebug = SMTP::DEBUG_OFF;
    $mail->isHTML(true);
    $mail->isSMTP();
    $mail->SMTPAuth = true;
    $mail->Host = "smtp.gmail.com";
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587;
	$mail->Username = "info@kodeit.com";
	$mail->Password = "brsd etrw cahh coyk";
	$mail->setFrom("info@kodeit.com", "noreply@riyadatraining.com");
	// $mail->addAddress("info@kodeit.com", "Kodeit");
	$mail->addAddress("waseem.ahmad202@gmail.com", "panworldllc");
    // $mail->addAddress("shweta@panworldllc.com", "panworldllc");
    $mail->addAddress("info@riyadatraining.com", "Riyada Training");
    $mail->Subject = "Riyada Training Response";
    $mail->Body = $message;
    $mail->send();
    header("Location: thank-you.html");
    exit();
} catch (Exception $e) {
    echo "Mailer Error: " . $mail->ErrorInfo;
 
}
?>
